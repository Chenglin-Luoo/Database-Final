<?php
require_once __DIR__.'/../config/db.php'; //引入数据库配置

//过滤输入数据
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data))); //去除HTML标签和空格并转义特殊字符
}

//执行SQL查询
function query($sql, $params = []) {
    $db = getDB(); //获取数据库连接
    $stmt = $db->prepare($sql); //准备SQL语句
    if (!$stmt) {
        die("SQL错误: " . $db->error); //SQL错误处理
    }
    
    if (!empty($params)) {
        $types = str_repeat('s', count($params)); //所有参数默认为字符串类型
        $stmt->bind_param($types, ...$params); //绑定参数
    }
    
    $stmt->execute(); //执行查询
    return $stmt;
}

//获取单行结果
function fetchOne($sql, $params = []) {
    $stmt = query($sql, $params);
    $result = $stmt->get_result(); //获取结果集
    return $result->fetch_assoc(); //返回关联数组
}

//获取多行结果
function fetchAll($sql, $params = []) {
    $stmt = query($sql, $params);
    $result = $stmt->get_result(); //获取结果集
    return $result->fetch_all(MYSQLI_ASSOC); //返回所有行
}

//重定向
function redirect($url) {
    header("Location: $url"); //设置重定向头
    exit; //终止脚本执行
}

//检查是否登录
function checkLogin() {
    return isset($_SESSION['user_id']); //检查会话中是否有用户ID
}

//检查是否是管理员
function isAdmin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin'; //检查用户角色
}

//获取最后插入的ID
function lastInsertId() {
    $db = getDB(); //获取数据库连接
    return $db->insert_id; //返回最后插入的ID
}