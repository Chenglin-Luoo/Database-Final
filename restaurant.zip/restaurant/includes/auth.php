<?php
require_once __DIR__.'/functions.php'; //引入功能函数

//用户登录验证
function login($username, $password) {
    $user = fetchOne("SELECT * FROM user WHERE username = ?", [$username]);
    if ($user && $password === $user['password']) { //验证密码
        $_SESSION['user_id'] = $user['user_id']; //设置会话变量
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        return true;
    }
    return false;
}

//用户注销处理
function logout() {
    session_unset(); //清除会话变量
    session_destroy(); //销毁会话
}

//用户注册功能
function register($username, $password, $role = 'user') {
    $sql = "INSERT INTO user (username, password, role) VALUES (?, ?, ?)";
    $stmt = query($sql, [$username, $password, $role]); //执行注册SQL
    return $stmt->affected_rows > 0; //返回注册结果
}

//检查用户名是否存在
function usernameExists($username) {
    $user = fetchOne("SELECT user_id FROM user WHERE username = ?", [$username]);
    return !empty($user); //返回检查结果
}