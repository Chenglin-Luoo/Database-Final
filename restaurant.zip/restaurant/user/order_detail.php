<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin()) { //检查用户登录状态
    redirect('/login.php'); //未登录则跳转
}

$order_id = $_GET['id'] ?? 0; //获取订单ID
if (!$order_id) { //无效ID则跳转
    redirect('orders.php');
}

//获取订单基本信息，确保只能查看自己的订单
$order = fetchOne("
    SELECT * FROM `orders` 
    WHERE order_id = ? AND user_id = ?
", [$order_id, $_SESSION['user_id']]);

if (!$order) { //订单不存在或不属于当前用户则跳转
    redirect('orders.php');
}

//获取订单项详情
$order_items = fetchAll("
    SELECT oi.*, d.dish_name 
    FROM order_item oi 
    JOIN dish d ON oi.dish_id = d.dish_id 
    WHERE oi.order_id = ?
", [$order_id]);
?>
<!DOCTYPE html>
<html>
<head>
    <title>订单详情</title>
    <link rel="stylesheet" href="/assets/css/simple-style.css">
    <style>
        .order-info { margin-bottom: 30px; } //订单信息区域样式
        .info-grid { //信息网格布局
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
        }
        .info-row { margin-bottom: 10px; } //信息行样式
        .info-label { font-weight: bold; } //标签样式
        .status { //状态标签样式
            padding: 3px 8px;
            border-radius: 4px;
        }
        .status-pending { color: #ff9800; } //待处理状态样式
        .status-completed { color: #4CAF50; } //已完成状态样式
        .status-cancelled { color: #f44336; } //已取消状态样式
        .total-row { //总计行样式
            font-weight: bold;
            background-color: rgba(52, 152, 219, 0.1);
        }
    </style>
</head>
<body>
    <h2>订单详情 #<?= $order['order_id'] ?></h2>
    <a href="orders.php">返回订单列表</a> //返回链接
    
    <div class="order-info">
        <h3>订单信息</h3>
        <p><strong>订单日期：</strong><?= $order['created_at'] ?></p> //显示订单日期
        <p><strong>状态：</strong><span class="status-<?= $order['status'] ?>">
            <?php 
                switch($order['status']) { //根据状态显示不同文本
                    case 'pending': echo '待处理'; break;
                    case 'completed': echo '已完成'; break;
                    case 'cancelled': echo '已取消'; break;
                    default: echo $order['status'];
                }
            ?>
        </span></p>
        <p><strong>总金额：</strong>¥<?= $order['total_amount'] ?></p> //显示总金额
        <p><strong>备注：</strong><?= htmlspecialchars($order['notes'] ?? '无') ?></p> //显示备注
        
        <?php if ($order['status'] === 'pending'): //仅待处理订单显示取消按钮 ?>
            <a href="order_action.php?action=cancel&id=<?= $order['order_id'] ?>" class="action-btn">取消订单</a>
        <?php endif; ?>
    </div>
    
    <h3>订单项</h3>
    <table>
        <thead>
            <tr>
                <th>菜品名称</th>
                <th>数量</th>
                <th>单价</th>
                <th>小计</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($order_items as $item): //遍历订单项 ?>
            <tr>
                <td><?= htmlspecialchars($item['dish_name']) ?></td> //显示菜品名称
                <td><?= $item['quantity'] ?></td> //显示数量
                <td>¥<?= $item['price'] ?></td> //显示单价
                <td>¥<?= $item['price'] * $item['quantity'] ?></td> //显示小计
            </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="3" style="text-align: right;"><strong>总计：</strong></td>
                <td><strong>¥<?= $order['total_amount'] ?></strong></td> //显示总计金额
            </tr>
        </tbody>
    </table>
</body>
</html>