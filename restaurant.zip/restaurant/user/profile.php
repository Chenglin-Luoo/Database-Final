<?php
session_start();
require_once __DIR__.'/../includes/auth.php';
require_once __DIR__.'/../includes/functions.php';

if (!checkLogin()) {
    redirect('/login.php');
}

// 获取当前用户信息
$user = fetchOne("SELECT * FROM user WHERE user_id = ?", [$_SESSION['user_id']]);
if (!$user) {
    redirect('/login.php');
}

$message = '';
$error = '';

// 处理个人信息更新
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');

    if (empty($username) || empty($email)) {
        $error = '用户名和邮箱不能为空';
    } else {
        query(
            "UPDATE user SET username = ?, email = ?, phone = ? WHERE user_id = ?",
            [$username, $email, $phone, $_SESSION['user_id']]
        );
        $message = '个人信息已更新';
        // 刷新用户信息
        $user = fetchOne("SELECT * FROM user WHERE user_id = ?", [$_SESSION['user_id']]);
    }
}

// 处理密码修改
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if (!password_verify($current_password, $user['password'])) {
        $error = '当前密码不正确';
    } elseif (empty($new_password)) {
        $error = '新密码不能为空';
    } elseif ($new_password !== $confirm_password) {
        $error = '两次输入的密码不一致';
    } else {
        query(
            "UPDATE user SET password = ? WHERE user_id = ?",
            [$new_password, $_SESSION['user_id']]
        );
        $message = '密码已更新';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>个人中心</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
        .profile-section, .password-section { 
            margin-bottom: 30px; 
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        h2 { margin-top: 0; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input[type="text"], input[type="email"], input[type="tel"], input[type="password"] {
            width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;
        }
        .message { 
            color: #28a745; 
            margin-bottom: 15px;
            padding: 10px;
            background-color: #e8f5e9;
            border-radius: 4px;
        }
        .error { 
            color: #dc3545; 
            margin-bottom: 15px;
            padding: 10px;
            background-color: #f8d7da;
            border-radius: 4px;
        }
        .action-btn { 
            display: inline-block; 
            padding: 10px 20px;
            background: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        .action-btn.secondary {
            background: #6c757d;
        }
    </style>
</head>
<body>
    <h1>个人中心</h1>
    <a href="index.php">返回首页</a>
    
    <?php if ($message): ?>
        <p class="message"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    
    <div class="profile-section">
        <h2>个人信息</h2>
        <form method="post">
            <div class="form-group">
                <label for="username">用户名</label>
                <input type="text" id="username" name="username" required 
                       value="<?= htmlspecialchars($user['username']) ?>">
            </div>
            <div class="form-group">
                <label for="email">邮箱</label>
                <input type="email" id="email" name="email" required 
                       value="<?= htmlspecialchars($user['email']) ?>">
            </div>
            <div class="form-group">
                <label for="phone">电话</label>
                <input type="tel" id="phone" name="phone" 
                       value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
            </div>
            
            <button type="submit" name="update_profile" class="action-btn">更新信息</button>
        </form>
    </div>
    
    <div class="password-section">
        <h2>修改密码</h2>
        <form method="post">
            <div class="form-group">
                <label for="current_password">当前密码</label>
                <input type="password" id="current_password" name="current_password" required>
            </div>
            <div class="form-group">
                <label for="new_password">新密码</label>
                <input type="password" id="new_password" name="new_password" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">确认新密码</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
            </div>
            
            <button type="submit" name="change_password" class="action-btn secondary">修改密码</button>
        </form>
    </div>
</body>
</html>