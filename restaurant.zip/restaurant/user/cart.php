<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin()) { //检查用户登录状态
    redirect('/login.php'); //未登录则跳转
}

//初始化购物车
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

//处理数量更新
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($_POST['quantity'] as $dish_id => $quantity) {
        $quantity = (int)$quantity; //转换为整数
        if ($quantity > 0) {
            $_SESSION['cart'][$dish_id] = $quantity; //更新数量
        } else {
            unset($_SESSION['cart'][$dish_id]); //移除商品
        }
    }
    //重定向避免重复提交
    redirect('cart.php');
}

//获取购物车中的菜品详情
$cart_items = [];
$total_amount = 0;

if (!empty($_SESSION['cart'])) {
    $dish_ids = array_keys($_SESSION['cart']); //获取所有菜品ID
    $placeholders = implode(',', array_fill(0, count($dish_ids), '?')); //创建SQL占位符
    
    $dishes = fetchAll("SELECT * FROM dish WHERE dish_id IN ($placeholders) AND status = 1", $dish_ids); //查询菜品信息
    
    foreach ($dishes as $dish) {
        $quantity = $_SESSION['cart'][$dish['dish_id']]; //获取数量
        $subtotal = $dish['price'] * $quantity; //计算小计
        $total_amount += $subtotal; //累加总金额
        
        $cart_items[] = [
            'dish_id' => $dish['dish_id'],
            'dish_name' => $dish['dish_name'],
            'price' => $dish['price'],
            'quantity' => $quantity,
            'subtotal' => $subtotal,
            'image' => $dish['image'] ?? null
        ];
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>我的购物车</title>
    <link rel="stylesheet" href="/assets/css/simple-style.css">
</head>
<body>
    <div class="header">
        <h2>我的购物车</h2>
        <a href="index.php" class="btn">继续购物</a> //返回按钮
    </div>
    
    <div class="card">
        <?php if (empty($cart_items)): //购物车为空显示提示 ?>
            <p>购物车为空</p>
        <?php else: //购物车有商品显示表格 ?>
            <form method="post">
                <table>
                    <thead>
                        <tr>
                            <th>菜品名称</th>
                            <th>单价</th>
                            <th>数量</th>
                            <th>小计</th>
                            <th>操作</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cart_items as $item): //遍历购物车商品 ?>
                        <tr>
                            <td><?= htmlspecialchars($item['dish_name']) ?></td> //显示菜品名称
                            <td>¥<?= $item['price'] ?></td> //显示单价
                            <td>
                                <input type="number" name="quantity[<?= $item['dish_id'] ?>]" 
                                       value="<?= $item['quantity'] ?>" min="1" style="width:60px;text-align:center"> //数量输入框
                            </td>
                            <td>¥<?= $item['subtotal'] ?></td> //显示小计
                            <td>
                                <a href="cart_action.php?action=remove&id=<?= $item['dish_id'] ?>" style="color:#f44336">删除</a> //删除按钮
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <tr style="font-weight:bold;background-color:#f5f5f5">
                            <td colspan="3" style="text-align:right">总计：</td>
                            <td>¥<?= $total_amount ?></td> //显示总金额
                            <td></td>
                        </tr>
                    </tbody>
                </table>
                <div style="margin-top:20px">
                    <button type="submit" class="btn">更新购物车</button> //更新按钮
                    <a href="checkout.php" class="btn" style="background:#4CAF50">结算</a> //结算按钮
                </div>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>