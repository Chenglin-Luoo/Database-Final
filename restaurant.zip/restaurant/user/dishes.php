<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin()) { //检查用户登录状态
    redirect('/login.php'); //未登录则跳转
}

//获取分类参数
$category = $_GET['category'] ?? '';
$where = "status = 1";
$params = [];

if ($category) {
    $where .= " AND category = ?"; //添加分类筛选条件
    $params[] = $category;
}

//获取所有上架菜品
$dishes = fetchAll("SELECT * FROM dish WHERE $where ORDER BY dish_id DESC", $params);

//获取所有分类用于筛选
$categories = fetchAll("SELECT DISTINCT category FROM dish WHERE status = 1 AND category IS NOT NULL");
?>
<!DOCTYPE html>
<html>
<head>
    <title>菜品列表</title>
    <link rel="stylesheet" href="/assets/css/simple-style.css">
    <style>
        .dishes { //菜品网格布局
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .dish { //单个菜品卡片样式
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background: white;
        }
        .dish img { //菜品图片样式
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-radius: 4px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>菜品列表</h2>
        <a href="index.php" class="btn">返回首页</a> //返回按钮
    </div>
    
    <div class="card">
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; } //基本样式
        .menu { display: flex; margin-bottom: 20px; } //菜单样式
        .menu a { margin-right: 15px; text-decoration: none; color: #007bff; } //菜单链接样式
        .header { display: flex; justify-content: space-between; margin-bottom: 30px; } //页头样式
        .dish-list { display: grid; grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); gap: 20px; } //菜品列表网格布局
        .dish-card { border: 1px solid #ddd; border-radius: 5px; padding: 15px; } //菜品卡片样式
        .dish-img { width: 100%; height: 180px; object-fit: cover; margin-bottom: 10px; } //菜品图片样式
        .dish-name { font-weight: bold; margin-bottom: 5px; } //菜品名称样式
        .dish-price { color: #e63946; margin-bottom: 10px; } //菜品价格样式
        .dish-desc { color: #666; margin-bottom: 10px; font-size: 14px; } //菜品描述样式
        .add-to-cart { //加入购物车按钮样式
            display: inline-block; 
            padding: 5px 10px;
            background: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 14px;
        }
        .category-filter { //分类筛选区域样式
            margin-bottom: 20px;
        }
        .category-filter a { //分类链接样式
            display: inline-block;
            margin-right: 10px;
            margin-bottom: 10px;
            padding: 5px 10px;
            background: #f8f9fa;
            border-radius: 4px;
            text-decoration: none;
        }
        .category-filter a.active { //当前选中分类样式
            background: #007bff;
            color: white;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>菜品列表</h2>
        <div>欢迎，<?= $_SESSION['username'] ?> | <a href="/logout.php">登出</a></div> //显示用户名和登出链接
    </div>
    
    <?php if (isset($_SESSION['success_message'])): //显示成功消息 ?>
        <div style="color: green; margin-bottom: 15px; padding: 10px; background-color: #e8f5e9; border-radius: 4px;">
            <?= $_SESSION['success_message'] ?>
        </div>
        <?php unset($_SESSION['success_message']); //显示后清除消息 ?>
    <?php endif; ?>
    
    <div class="menu">
        <a href="index.php">用户中心</a>
        <a href="orders.php">我的订单</a>
        <a href="cart.php">购物车</a> //导航菜单
    </div>

    <div class="category-filter">
        <a href="dishes.php" class="<?= !$category ? 'active' : '' ?>">全部</a> //全部分类链接
        <?php foreach ($categories as $cat): //遍历所有分类 ?>
            <a href="dishes.php?category=<?= urlencode($cat['category']) ?>" 
               class="<?= $category == $cat['category'] ? 'active' : '' ?>">
                <?= htmlspecialchars($cat['category']) ?>
            </a>
        <?php endforeach; ?>
    </div>
    
    <div class="dish-list">
        <?php foreach ($dishes as $dish): //遍历所有菜品 ?>
        <div class="dish-card">
            <?php if ($dish['image']): //显示菜品图片 ?>
                <img src="/uploads/<?= htmlspecialchars($dish['image']) ?>" alt="<?= htmlspecialchars($dish['dish_name']) ?>" class="dish-img">
            <?php else: //无图片时显示占位符 ?>
                <div class="dish-img" style="background: #eee; display: flex; align-items: center; justify-content: center;">
                    <span>暂无图片</span>
                </div>
            <?php endif; ?>
            <div class="dish-name"><?= htmlspecialchars($dish['dish_name']) ?></div> //显示菜品名称
            <div class="dish-price">¥<?= $dish['price'] ?></div> //显示菜品价格
            <?php if ($dish['category']): //显示菜品分类 ?>
                <div style="color: #6c757d; font-size: 12px; margin-bottom: 5px;"><?= htmlspecialchars($dish['category']) ?></div>
            <?php endif; ?>
            <div class="dish-desc"><?= htmlspecialchars($dish['description']) ?></div> //显示菜品描述
            <a href="cart_action.php?action=add&id=<?= $dish['dish_id'] ?>" class="add-to-cart">加入购物车</a> //加入购物车按钮
        </div>
        <?php endforeach; ?>
    </div>
</body>
</html>