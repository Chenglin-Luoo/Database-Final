<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin()) { //检查用户登录状态
    redirect('/login.php'); //未登录则跳转
}

//检查购物车是否为空
if (empty($_SESSION['cart'])) {
    redirect('cart.php');
}

//获取购物车中的菜品详情
$cart_items = [];
$total_amount = 0;
$dish_ids = array_keys($_SESSION['cart']); //获取所有菜品ID
$placeholders = implode(',', array_fill(0, count($dish_ids), '?')); //创建SQL占位符

$dishes = fetchAll("SELECT * FROM dish WHERE dish_id IN ($placeholders) AND status = 1", $dish_ids); //查询菜品信息

foreach ($dishes as $dish) {
    $quantity = $_SESSION['cart'][$dish['dish_id']]; //获取数量
    $subtotal = $dish['price'] * $quantity; //计算小计
    $total_amount += $subtotal; //累加总金额
    
    $cart_items[] = [
        'dish_id' => $dish['dish_id'],
        'dish_name' => $dish['dish_name'],
        'price' => $dish['price'],
        'quantity' => $quantity,
        'subtotal' => $subtotal
    ];
}

//处理订单提交
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $notes = trim($_POST['notes'] ?? ''); //获取备注信息
    
    //创建订单
    query(
        "INSERT INTO `orders` (user_id, total_amount, remark, status) 
         VALUES (?, ?, ?, 'pending')",
        [$_SESSION['user_id'], $total_amount, $notes]
    );
    $order_id = lastInsertId(); //获取新订单ID
    
    //检查订单是否创建成功
    if (!$order_id) {
        die("订单创建失败，请重试");
    }
    
    //添加订单项
    foreach ($cart_items as $item) {
        query(
            "INSERT INTO order_item (order_id, dish_id, quantity, unit_price) 
             VALUES (?, ?, ?, ?)",
            [$order_id, $item['dish_id'], $item['quantity'], $item['price']]
        );
    }
    
    //清空购物车
    $_SESSION['cart'] = [];
    
    //重定向到订单详情
    redirect("order_detail.php?id=$order_id");
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>结算订单</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; } //基本样式
        table { width: 100%; border-collapse: collapse; margin-top: 20px; } //表格样式
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; } //表格单元格样式
        th { background-color: #f2f2f2; } //表头样式
        .form-group { margin-bottom: 15px; } //表单组样式
        label { display: block; margin-bottom: 5px; font-weight: bold; } //标签样式
        input[type="text"], input[type="tel"], textarea {
            width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px; //输入框样式
        }
        .error { color: #dc3545; margin-bottom: 15px; } //错误信息样式
        .action-btn { 
            display: inline-block; 
            margin-top: 15px;
            padding: 10px 20px;
            background: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 16px; //按钮样式
        }
        .total-row {
            font-weight: bold;
            background-color: #f8f9fa; //总计行样式
        }
    </style>
</head>
<body>
    <h2>结算订单</h2>
    <a href="cart.php">返回购物车</a> //返回链接
    
    <?php if (isset($error)): //显示错误信息 ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php endif; ?>
    
    <h3>订单商品</h3>
    <table>
        <thead>
            <tr>
                <th>菜品名称</th>
                <th>单价</th>
                <th>数量</th>
                <th>小计</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($cart_items as $item): //遍历购物车商品 ?>
            <tr>
                <td><?= htmlspecialchars($item['dish_name']) ?></td> //显示菜品名称
                <td>¥<?= $item['price'] ?></td> //显示单价
                <td><?= $item['quantity'] ?></td> //显示数量
                <td>¥<?= $item['subtotal'] ?></td> //显示小计
            </tr>
            <?php endforeach; ?>
            <tr class="total-row">
                <td colspan="3" style="text-align: right;">总计：</td>
                <td>¥<?= $total_amount ?></td> //显示总金额
            </tr>
        </tbody>
    </table>
    
    <h3>订单备注</h3>
    <form method="post">
        <div class="form-group">
            <label for="notes">备注(可选)</label>
            <textarea id="notes" name="notes" rows="3"><?= 
                htmlspecialchars($_POST['notes'] ?? '') //显示已输入的备注
            ?></textarea>
        </div>
        
        <button type="submit" class="action-btn">提交订单</button> //提交按钮
    </form>
</body>
</html>