<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin()) { //检查用户登录状态
    redirect('/login.php'); //未登录则跳转
}

//获取当前用户的订单，按时间降序排列
$orders = fetchAll("
    SELECT * FROM `orders` 
    WHERE user_id = ? 
    ORDER BY order_time DESC
", [$_SESSION['user_id']]);
?>
<!DOCTYPE html>
<html>
<head>
    <title>我的订单</title>
    <link rel="stylesheet" href="/assets/css/simple-style.css">
</head>
<body>
    <div class="header">
        <h2>我的订单</h2>
        <a href="index.php" class="btn">返回首页</a> //返回按钮
    </div>
    
    <div class="card">
        <table class="table">
            <thead>
                <tr>
                    <th>订单ID</th>
                    <th>订单日期</th>
                    <th>总金额</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): //遍历用户订单 ?>
                <tr>
                    <td><?= $order['order_id'] ?></td>
                    <td><?= $order['order_date'] ?></td>
                    <td>¥<?= $order['total_amount'] ?></td>
                    <td>
                        <?php 
                            switch($order['status']) { //根据状态显示不同颜色
                                case 'pending': echo '<span style="color:#ff9800">待处理</span>'; break;
                                case 'completed': echo '<span style="color:#4CAF50">已完成</span>'; break;
                                case 'cancelled': echo '<span style="color:#f44336">已取消</span>'; break;
                                default: echo $order['status'];
                            }
                        ?>
                    </td>
                    <td>
                        <a href="order_detail.php?id=<?= $order['order_id'] ?>" class="btn">查看详情</a> //详情按钮
                        <?php if ($order['status'] === 'pending'): //仅待处理订单可取消 ?>
                            <a href="order_action.php?action=cancel&id=<?= $order['order_id'] ?>" class="btn" style="background:#f44336">取消订单</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>