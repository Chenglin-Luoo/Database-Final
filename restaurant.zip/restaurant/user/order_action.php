<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin()) { //检查用户登录状态
    redirect('/login.php'); //未登录则跳转
}

$action = $_GET['action'] ?? ''; //获取操作类型
$id = $_GET['id'] ?? 0; //获取订单ID

if ($id && $action === 'cancel') { //取消订单操作
    //验证订单属于当前用户
    $order = fetchOne("SELECT status FROM `orders` WHERE order_id = ? AND user_id = ?", 
                      [$id, $_SESSION['user_id']]);
    
    if ($order && $order['status'] === 'pending') { //仅允许取消待处理订单
        query("UPDATE `orders` SET status = 'cancelled' WHERE order_id = ?", [$id]);
    }
}

redirect('orders.php'); //返回订单列表