<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin()) { //检查用户登录状态
    redirect('/login.php'); //未登录则跳转
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>用户中心</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; } //基本样式
        .menu { display: flex; margin-bottom: 20px; } //菜单样式
        .menu a { margin-right: 15px; text-decoration: none; color: #007bff; } //菜单链接样式
        .header { display: flex; justify-content: space-between; margin-bottom: 30px; } //页头样式
    </style>
</head>
<body>
    <div class="header">
        <h2>用户中心</h2>
        <div>欢迎，<?= $_SESSION['username'] ?> | <a href="/logout.php">登出</a></div> //显示用户名和登出链接
    </div>
    
    <div class="menu">
        <a href="dishes.php">菜品列表</a>
        <a href="orders.php">我的订单</a>
        <a href="cart.php">购物车</a> //用户导航菜单
    </div>
    
    <div>
        <h3>欢迎使用订餐系统</h3>
        <p>请从上方菜单选择功能</p> //欢迎信息
    </div>
</body>
</html>