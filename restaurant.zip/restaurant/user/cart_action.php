<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin()) { //检查用户登录状态
    redirect('/login.php'); //未登录则跳转
}

//初始化购物车
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$action = $_GET['action'] ?? ''; //获取操作类型
$id = $_GET['id'] ?? 0; //获取菜品ID

    if ($id) {
        if ($action === 'add') {
            //添加商品到购物车
            $quantity = $_GET['quantity'] ?? 1; //获取数量，默认为1
            if (isset($_SESSION['cart'][$id])) {
                $_SESSION['cart'][$id] += $quantity; //已存在则增加数量
            } else {
                $_SESSION['cart'][$id] = $quantity; //不存在则添加
            }
            $_SESSION['success_message'] = '商品已成功添加到购物车';
        } elseif ($action === 'remove') {
            //从购物车移除商品
            unset($_SESSION['cart'][$id]);
            redirect('cart.php');
            return;
        }
    }

    //返回来源页面
    $referer = $_SERVER['HTTP_REFERER'] ?? 'dishes.php';
    redirect($referer);