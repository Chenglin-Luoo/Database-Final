<?php
//数据库连接参数
define('DB_HOST', 'food');
define('DB_USER', '4567');
define('DB_PASS', '456789');  
define('DB_NAME', 'food');

//获取数据库连接实例
function getDB() {
    static $db = null;
    if ($db === null) {
        $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME); //创建连接
        if ($db->connect_error) {
            die("数据库连接失败: " . $db->connect_error); //连接失败处理
        }
        $db->set_charset("utf8mb4"); //设置字符集
    }
    return $db;
}