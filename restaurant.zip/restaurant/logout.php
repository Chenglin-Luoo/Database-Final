<?php
session_start(); //启动会话
require_once __DIR__.'/includes/auth.php'; //引入认证相关函数

logout(); //执行注销操作
redirect('/login.php'); //重定向到登录页面