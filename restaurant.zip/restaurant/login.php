<?php
session_start(); //启动会话
require_once __DIR__.'/includes/auth.php'; //引入认证函数
require_once __DIR__.'/includes/functions.php'; //引入功能函数

$error = ''; //错误信息变量
if ($_SERVER['REQUEST_METHOD'] === 'POST') { //处理表单提交
    $username = sanitize($_POST['username']); //过滤用户名
    $password = sanitize($_POST['password']); //过滤密码
    
    if (login($username, $password)) { //尝试登录
        redirect(isAdmin() ? '/admin/index.php' : '/user/index.php'); //根据角色重定向
    } else {
        $error = '用户名或密码错误'; //设置错误信息
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>登录</title>
    <link rel="stylesheet" href="/assets/css/simple-style.css">
</head>
<body>
    <div class="card" style="max-width:400px;margin:50px auto">
        <h2 style="text-align:center">登录</h2>
        <?php if ($error): //显示错误信息 ?>
            <div style="color:#f44336;margin-bottom:15px"><?= $error ?></div>
        <?php endif; ?>
        <form method="post">
            <div class="form-group">
                <input type="text" name="username" placeholder="用户名" required>
            </div>
            <div class="form-group">
                <input type="password" name="password" placeholder="密码" required>
            </div>
            <button type="submit" class="btn" style="width:100%">登录</button>
        </form>
        <p style="text-align:center;margin-top:15px">还没有账号？<a href="register.php">注册</a></p> //注册链接
    </div>
</body>
</html>