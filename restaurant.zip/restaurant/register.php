<?php
session_start(); //启动会话
require_once __DIR__.'/includes/auth.php'; //引入认证函数
require_once __DIR__.'/includes/functions.php'; //引入功能函数

$error = ''; //错误信息变量
if ($_SERVER['REQUEST_METHOD'] === 'POST') { //处理表单提交
    $username = sanitize($_POST['username']); //过滤用户名
    $password = sanitize($_POST['password']); //过滤密码
    
    if (usernameExists($username)) { //检查用户名是否存在
        $error = '用户名已存在';
    } else {
        if (register($username, $password)) { //尝试注册
            login($username, $password); //自动登录
            redirect(isAdmin() ? '/admin/index.php' : '/user/index.php'); //根据角色重定向
        } else {
            $error = '注册失败，请重试'; //设置错误信息
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>注册</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 400px; margin: 0 auto; padding: 20px; } //基本样式
        .form-group { margin-bottom: 15px; } //表单组样式
        input { width: 100%; padding: 8px; box-sizing: border-box; } //输入框样式
        button { background: #007bff; color: white; border: none; padding: 10px; width: 100%; cursor: pointer; } //按钮样式
        .error { color: red; margin-bottom: 15px; } //错误信息样式
    </style>
</head>
<body>
    <h2>注册</h2>
    <?php if ($error): //显示错误信息 ?>
        <div class="error"><?= $error ?></div>
    <?php endif; ?>
    <form method="post">
        <div class="form-group">
            <input type="text" name="username" placeholder="用户名" required>
        </div>
        <div class="form-group">
            <input type="password" name="password" placeholder="密码" required>
        </div>
        <button type="submit">注册</button>
    </form>
    <p>已有账号？<a href="login.php">登录</a></p> //登录链接
</body>
</html>