<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin() || !isAdmin()) { //检查管理员登录状态
    redirect('/login.php'); //未登录则跳转
}

$action = $_GET['action'] ?? ''; //获取操作类型
$dish = null; //菜品数据
$errors = []; //错误信息数组

if ($action === 'edit' && isset($_GET['id'])) { //编辑模式
    $dish = fetchOne("SELECT * FROM dish WHERE dish_id = ?", [$_GET['id']]); //获取菜品信息
    if (!$dish) { //菜品不存在则跳转
        redirect('dishes.php');
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') { //处理表单提交
    $dish_name = sanitize($_POST['dish_name']); //过滤菜品名称
    $description = sanitize($_POST['description']); //过滤描述
    $price = (float)$_POST['price']; //转换价格为浮点数
    $stock = (int)$_POST['stock']; //转换库存为整数
    $category = sanitize($_POST['category']); //过滤分类
    $status = isset($_POST['status']) ? 1 : 0; //获取状态
    
    //表单验证
    if (empty($dish_name)) {
        $errors[] = '菜品名称不能为空';
    }
    if ($price <= 0) {
        $errors[] = '价格必须大于0';
    }
    if ($stock < 0) {
        $errors[] = '库存不能为负数';
    }

    if (empty($errors)) { //无错误则保存
        if ($action === 'add') { //添加菜品
            $sql = "INSERT INTO dish (dish_name, description, price, stock, category, status) 
                    VALUES (?, ?, ?, ?, ?, ?)";
            query($sql, [$dish_name, $description, $price, $stock, $category, $status]);
            redirect('dishes.php');
        } elseif ($action === 'edit' && isset($_POST['dish_id'])) { //更新菜品
            $sql = "UPDATE dish SET 
                    dish_name = ?, description = ?, price = ?, stock = ?, category = ?, status = ? 
                    WHERE dish_id = ?";
            query($sql, [$dish_name, $description, $price, $stock, $category, $status, $_POST['dish_id']]);
            redirect('dishes.php');
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title><?= $action === 'add' ? '添加菜品' : '编辑菜品' ?></title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; }
        input, textarea, select { width: 100%; padding: 8px; box-sizing: border-box; }
        .error { color: red; margin-bottom: 15px; }
        .btn { background: #007bff; color: white; border: none; padding: 10px; cursor: pointer; }
    </style>
</head>
<body>
    <h2><?= $action === 'add' ? '添加菜品' : '编辑菜品' ?></h2>
    <a href="dishes.php">返回列表</a>
    
    <?php if (!empty($errors)): ?>
        <div class="error">
            <?php foreach ($errors as $error): ?>
                <p><?= $error ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    
    <form method="post">
        <?php if ($action === 'edit'): ?>
            <input type="hidden" name="dish_id" value="<?= $dish['dish_id'] ?>">
        <?php endif; ?>
        
        <div class="form-group">
            <label for="dish_name">菜品名称</label>
            <input type="text" id="dish_name" name="dish_name" required 
                   value="<?= $dish['dish_name'] ?? '' ?>">
        </div>
        
        <div class="form-group">
            <label for="description">描述</label>
            <textarea id="description" name="description"><?= $dish['description'] ?? '' ?></textarea>
        </div>
        
        <div class="form-group">
            <label for="price">价格</label>
            <input type="number" id="price" name="price" step="0.01" min="0" required 
                   value="<?= $dish['price'] ?? '' ?>">
        </div>
        
        <div class="form-group">
            <label for="stock">库存</label>
            <input type="number" id="stock" name="stock" min="0" required 
                   value="<?= $dish['stock'] ?? '' ?>">
        </div>
        
        <div class="form-group">
            <label for="category">分类</label>
            <input type="text" id="category" name="category" 
                   value="<?= $dish['category'] ?? '' ?>">
        </div>
        
        <div class="form-group">
            <label>
                <input type="checkbox" name="status" <?= isset($dish['status']) && $dish['status'] ? 'checked' : '' ?>>
                上架
            </label>
        </div>
        
        <button type="submit" class="btn">保存</button>
    </form>
</body>
</html>