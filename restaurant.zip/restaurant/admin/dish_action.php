<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin() || !isAdmin()) { //检查管理员登录状态
    redirect('/login.php'); //未登录则跳转
}

$action = $_GET['action'] ?? ''; //获取操作类型
$id = $_GET['id'] ?? 0; //获取菜品ID

if ($action === 'delete' && $id) { //删除菜品
    query("DELETE FROM dish WHERE dish_id = ?", [$id]);
} elseif ($action === 'toggle_status' && $id) { //切换菜品状态
    $dish = fetchOne("SELECT status FROM dish WHERE dish_id = ?", [$id]);
    if ($dish) {
        $newStatus = $dish['status'] ? 0 : 1; //状态取反
        query("UPDATE dish SET status = ? WHERE dish_id = ?", [$newStatus, $id]);
    }
}

redirect('dishes.php'); //返回菜品列表