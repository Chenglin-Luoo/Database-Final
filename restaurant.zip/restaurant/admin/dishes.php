<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin() || !isAdmin()) { //检查管理员登录状态
    redirect('/login.php'); //未登录则跳转
}

//获取所有菜品
$dishes = fetchAll("SELECT * FROM dish ORDER BY dish_id DESC"); //按ID降序排列
?>
<!DOCTYPE html>
<html>
<head>
    <title>菜品管理</title>
    <link rel="stylesheet" href="/assets/css/simple-style.css">
</head>
<body>
    <div class="header">
        <h2>菜品管理</h2>
        <a href="index.php" class="btn">返回后台</a> //返回按钮
    </div>
    
    <div class="action-bar">
        <a href="dish_edit.php?action=add" class="btn btn-secondary">添加菜品</a> //添加菜品按钮
    </div>
    
    <div class="card">
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>菜品名称</th>
                    <th>描述</th>
                    <th>价格</th>
                    <th>库存</th>
                    <th>分类</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dishes as $dish): //遍历所有菜品 ?>
                <tr>
                    <td><?= $dish['dish_id'] ?></td>
                    <td><?= htmlspecialchars($dish['dish_name']) ?></td> //转义显示菜品名
                    <td><?= htmlspecialchars($dish['description']) ?></td> //转义显示描述
                    <td>¥<?= $dish['price'] ?></td>
                    <td><?= $dish['stock'] ?></td>
                    <td><?= htmlspecialchars($dish['category']) ?></td> //转义显示分类
                    <td>
                        <span class="status <?= $dish['status'] ? 'status-completed' : 'status-cancelled' ?>">
                            <?= $dish['status'] ? '上架' : '下架' ?> //根据状态显示不同文本
                        </span>
                    </td>
                    <td class="action-buttons">
                        <a href="dish_edit.php?action=edit&id=<?= $dish['dish_id'] ?>" class="btn">编辑</a> //编辑按钮
                        <a href="dish_action.php?action=delete&id=<?= $dish['dish_id'] ?>" class="btn btn-danger">删除</a> //删除按钮
                        <a href="dish_action.php?action=toggle_status&id=<?= $dish['dish_id'] ?>" class="btn btn-warning">
                            <?= $dish['status'] ? '下架' : '上架' ?> //切换状态按钮
                        </a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>