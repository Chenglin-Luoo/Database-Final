<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin() || !isAdmin()) { //检查管理员登录状态
    redirect('/login.php'); //未登录则跳转
}

$action = $_GET['action'] ?? ''; //获取操作类型
$id = $_GET['id'] ?? 0; //获取订单ID

if ($id) { //有订单ID时处理
    if ($action === 'complete') { //完成订单操作
        query("UPDATE `orders` SET status = 'completed' WHERE order_id = ?", [$id]);
    } elseif ($action === 'cancel') { //取消订单操作
        query("UPDATE `orders` SET status = 'cancelled' WHERE order_id = ?", [$id]);
    }
}

redirect('orders.php'); //返回订单列表