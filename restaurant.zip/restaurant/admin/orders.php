<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin() || !isAdmin()) { //检查管理员登录状态
    redirect('/login.php'); //未登录则跳转
}

//获取所有订单，按时间降序排列
$orders = fetchAll("
    SELECT o.*, u.username 
    FROM `orders` o 
    JOIN user u ON o.user_id = u.user_id 
    ORDER BY o.order_time DESC
");
?>
<!DOCTYPE html>
<html>
<head>
    <title>订单管理</title>
    <link rel="stylesheet" href="/assets/css/simple-style.css">
</head>
<body>
    <div class="header">
        <h2>订单管理</h2>
        <a href="index.php" class="btn">返回后台</a> //返回按钮
    </div>
    
    <div class="card">
        <table>
            <thead>
                <tr>
                    <th>订单ID</th>
                    <th>用户</th>
                    <th>订单日期</th>
                    <th>总金额</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order): //遍历所有订单 ?>
                <tr>
                    <td><?= $order['order_id'] ?></td>
                    <td><?= htmlspecialchars($order['username']) ?></td> //转义显示用户名
                    <td><?= $order['order_date'] ?></td>
                    <td>¥<?= $order['total_amount'] ?></td>
                    <td>
                        <?php 
                            switch($order['status']) { //根据状态显示不同颜色
                                case 'pending': echo '<span style="color:#ff9800">待处理</span>'; break;
                                case 'completed': echo '<span style="color:#4CAF50">已完成</span>'; break;
                                case 'cancelled': echo '<span style="color:#f44336">已取消</span>'; break;
                                default: echo $order['status'];
                            }
                        ?>
                    </td>
                    <td>
                        <a href="order_detail.php?id=<?= $order['order_id'] ?>" class="btn">查看详情</a>
                        <?php if ($order['status'] === 'pending'): //仅待处理订单显示操作按钮 ?>
                            <a href="order_action.php?action=complete&id=<?= $order['order_id'] ?>" class="btn" style="background:#4CAF50">完成</a>
                            <a href="order_action.php?action=cancel&id=<?= $order['order_id'] ?>" class="btn" style="background:#f44336">取消</a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>