<?php
session_start(); //启动会话
require_once __DIR__.'/../includes/auth.php'; //引入认证函数
require_once __DIR__.'/../includes/functions.php'; //引入功能函数

if (!checkLogin() || !isAdmin()) { //检查管理员登录状态
    redirect('/login.php'); //未登录则跳转
}

$order_id = $_GET['id'] ?? 0; //获取订单ID
if (!$order_id) { //无效ID则跳转
    redirect('orders.php');
}

//获取订单基本信息
$order = fetchOne("
    SELECT o.*, u.username 
    FROM `orders` o 
    JOIN user u ON o.user_id = u.user_id 
    WHERE o.order_id = ?
", [$order_id]);

if (!$order) { //订单不存在则跳转
    redirect('orders.php');
}

//获取订单项详情
$order_items = fetchAll("
    SELECT oi.*, d.dish_name 
    FROM order_item oi 
    JOIN dish d ON oi.dish_id = d.dish_id 
    WHERE oi.order_id = ?
", [$order_id]);

//调试信息记录
error_log("订单ID: $order_id, 订单项数量: " . count($order_items));
?>
<!DOCTYPE html>
<html>
<head>
    <title>订单详情</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; } //基本样式
        .order-info { margin-bottom: 30px; } //订单信息区域样式
        table { width: 100%; border-collapse: collapse; margin-top: 20px; } //表格样式
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; } //表格单元格样式
        th { background-color: #f2f2f2; } //表头样式
        .status-pending { color: #ffc107; } //待处理状态样式
        .status-completed { color: #28a745; } //已完成状态样式
        .status-cancelled { color: #dc3545; } //已取消状态样式
    </style>
</head>
<body>
    <h2>订单详情 #<?= $order['order_id'] ?></h2>
    <a href="orders.php">返回订单列表</a> //返回链接
    
    <div class="order-info">
        <h3>订单信息</h3>
        <p><strong>用户：</strong><?= htmlspecialchars($order['username']) ?></p> //显示用户名
        <p><strong>订单日期：</strong><?= $order['order_date'] ?></p> //显示订单日期
        <p><strong>状态：</strong><span class="status-<?= $order['status'] ?>">
            <?php 
                switch($order['status']) { //根据状态显示不同文本
                    case 'pending': echo '待处理'; break;
                    case 'completed': echo '已完成'; break;
                    case 'cancelled': echo '已取消'; break;
                    default: echo $order['status'];
                }
            ?>
        </span></p>
        <p><strong>总金额：</strong>¥<?= $order['total_amount'] ?></p> //显示总金额
        <p><strong>备注：</strong><?= htmlspecialchars($order['notes'] ?? '无') ?></p> //显示备注
    </div>
    
    <h3>订单项</h3>
    <table>
        <thead>
            <tr>
                <th>菜品名称</th>
                <th>数量</th>
                <th>单价</th>
                <th>小计</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($order_items as $item): //遍历订单项 ?>
            <tr>
                <td><?= htmlspecialchars($item['dish_name']) ?></td> //显示菜品名称
                <td><?= $item['quantity'] ?></td> //显示数量
                <td>¥<?= $item['price'] ?></td> //显示单价
                <td>¥<?= $item['price'] * $item['quantity'] ?></td> //显示小计
            </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="3" style="text-align: right;"><strong>总计：</strong></td>
                <td><strong>¥<?= $order['total_amount'] ?></strong></td> //显示总计金额
            </tr>
        </tbody>
    </table>
</body>
</html>